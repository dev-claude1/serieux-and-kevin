# Stock Management System

A complete full-stack stock management project based on the supplied practical assignment.

**Stack:** React + Vite, Node.js + Express, MySQL  
**Features:** dashboard, product registration, live product table, search, category filter, edit, delete, stock status, validation, responsive design, and API error handling.

## 1. Requirements

Install:
- Node.js 18+ (LTS recommended)
- MySQL Server 8+ (or MariaDB 10.5+)
- A code editor such as VS Code

Check installations:

```bash
node -v
npm -v
mysql --version
```

## 2. Create the database

Start MySQL, then open MySQL Workbench or the MySQL command line and run:

```sql
CREATE DATABASE IF NOT EXISTS stock_management;
USE stock_management;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(100) NOT NULL,
  category VARCHAR(80) NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO products (product_name, category, quantity, unit_price) VALUES
('Sugar', 'Food', 20, 2000.00),
('Soap', 'Hygiene', 15, 1500.00),
('Rice', 'Food', 30, 2500.00);
```

The `id` is generated automatically by MySQL. Do not send it when creating a product.

## 3. Configure the backend

Open a terminal in the project folder:

```bash
cd backend
npm install
```

Copy `.env.example` to `.env` and update the values to match your local MySQL setup:

```env
PORT=5000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=stock_management
```

If your MySQL root account has no password, leave `DB_PASSWORD=` empty.

Start the API:

```bash
npm run dev
```

You should see a message that the API is running and MySQL is connected. Keep this terminal open.

API health check: http://localhost:5000/api/health

## 4. Start the React frontend

Open a **second terminal** in the project folder:

```bash
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite, usually:

http://localhost:5173

The frontend uses Vite's development proxy to send `/api` requests to `http://localhost:5000`.

## 5. How to use the application

1. Open the dashboard.
2. Enter Product Name, Category, Quantity and Unit Price in **Add a product**.
3. Select **Add product**. The form validates required values and positive quantity / non-negative price.
4. The new record appears in the product table without reloading the page.
5. Use the search box or category filter to find products.
6. Select **Edit** to update a record, or **Delete** to remove it after confirmation.
7. Dashboard totals update from the records returned by the backend.

## 6. Test the API manually (optional)

List products:

```bash
curl http://localhost:5000/api/products
```

Create a product:

```bash
curl -X POST http://localhost:5000/api/products \
  -H "Content-Type: application/json" \
  -d '{"product_name":"Milk","category":"Drinks","quantity":12,"unit_price":1800}'
```

Update a product:

```bash
curl -X PUT http://localhost:5000/api/products/1 \
  -H "Content-Type: application/json" \
  -d '{"product_name":"Sugar","category":"Food","quantity":25,"unit_price":2000}'
```

Delete a product:

```bash
curl -X DELETE http://localhost:5000/api/products/1
```

## 7. Project structure

```text
stock-management-system/
├── backend/
│   ├── config/database.js
│   ├── routes/products.js
│   ├── .env.example
│   ├── index.js
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── database/schema.sql
└── README.md
```

## Troubleshooting

- **Access denied for user:** check `DB_USER` and `DB_PASSWORD` in `backend/.env`.
- **Unknown database:** run the SQL in `database/schema.sql`.
- **ECONNREFUSED / API unavailable:** make sure the backend terminal is still running on port 5000.
- **Port already in use:** change `PORT` in `backend/.env`; also update `server.proxy` in `frontend/vite.config.js` if you change the backend port.
- **Frontend dependencies missing:** run `npm install` inside `frontend`.
- **Products do not appear:** check the backend terminal and confirm the database table is named `products`.

## Assignment coverage

- React frontend communicates with a separate Express backend over HTTP.
- `GET /api/products` retrieves MySQL records and returns JSON.
- `POST /api/products` validates and inserts a product.
- `PUT` and `DELETE` are included as useful extra CRUD operations.
- Product ID is an auto-increment primary key.
- Errors and empty states are shown in the interface.
- Successful create/update/delete refreshes the table without a full page reload.
