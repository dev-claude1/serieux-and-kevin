CREATE DATABASE IF NOT EXISTS stock_management;
USE stock_management;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(100) NOT NULL,
  category VARCHAR(80) NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO products (product_name, category, quantity, unit_price)
SELECT 'Sugar', 'Food', 20, 2000.00
WHERE NOT EXISTS (SELECT 1 FROM products WHERE product_name = 'Sugar');

INSERT INTO products (product_name, category, quantity, unit_price)
SELECT 'Soap', 'Hygiene', 15, 1500.00
WHERE NOT EXISTS (SELECT 1 FROM products WHERE product_name = 'Soap');

INSERT INTO products (product_name, category, quantity, unit_price)
SELECT 'Rice', 'Food', 30, 2500.00
WHERE NOT EXISTS (SELECT 1 FROM products WHERE product_name = 'Rice');
