import { useEffect, useMemo, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, Boxes, Check,
  ChevronDown, CircleDollarSign, ClipboardList, Edit3, LayoutDashboard,
  Package, Plus, Search, ShieldCheck, Sparkles, Trash2, TrendingUp,
  X, RefreshCw, Menu, MoreHorizontal
} from 'lucide-react';

const money = (value) => new Intl.NumberFormat('en-RW', {
  style: 'currency', currency: 'RWF', maximumFractionDigits: 0
}).format(Number(value || 0));

const emptyForm = { product_name: '', category: '', quantity: '', unit_price: '' };

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message || 'Something went wrong.');
  return payload;
}

function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [query, setQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All categories');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  async function loadProducts() {
    setLoading(true);
    setError('');
    try {
      const result = await request('/api/products');
      setProducts(result.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadProducts(); }, []);

  const categories = useMemo(
    () => ['All categories', ...new Set(products.map((p) => p.category))],
    [products]
  );
  const filtered = useMemo(() => products.filter((p) => {
    const matchesQuery = `${p.product_name} ${p.category} ${p.id}`.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = categoryFilter === 'All categories' || p.category === categoryFilter;
    return matchesQuery && matchesCategory;
  }), [products, query, categoryFilter]);

  const totalUnits = products.reduce((sum, p) => sum + Number(p.quantity), 0);
  const inventoryValue = products.reduce((sum, p) => sum + Number(p.quantity) * Number(p.unit_price), 0);
  const lowStock = products.filter((p) => Number(p.quantity) <= 5).length;
  const avgPrice = products.length ? products.reduce((sum, p) => sum + Number(p.unit_price), 0) / products.length : 0;

  function openCreate() {
    setEditing(null); setForm(emptyForm); setModalOpen(true);
  }
  function openEdit(product) {
    setEditing(product);
    setForm({
      product_name: product.product_name,
      category: product.category,
      quantity: String(product.quantity),
      unit_price: String(product.unit_price)
    });
    setModalOpen(true);
  }
  function closeModal() {
    if (!saving) { setModalOpen(false); setEditing(null); setForm(emptyForm); }
  }
  function updateField(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  }
  async function submitProduct(event) {
    event.preventDefault();
    setSaving(true); setNotice(''); setError('');
    const body = {
      product_name: form.product_name.trim(),
      category: form.category.trim(),
      quantity: Number(form.quantity),
      unit_price: Number(form.unit_price)
    };
    try {
      const url = editing ? `/api/products/${editing.id}` : '/api/products';
      await request(url, { method: editing ? 'PUT' : 'POST', body: JSON.stringify(body) });
      await loadProducts();
      setNotice(editing ? 'Product updated successfully.' : 'Product added to your inventory.');
      setModalOpen(false); setEditing(null); setForm(emptyForm);
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  }
  async function deleteProduct(product) {
    if (!window.confirm(`Delete "${product.product_name}" from your inventory?`)) return;
    setNotice(''); setError('');
    try {
      await request(`/api/products/${product.id}`, { method: 'DELETE' });
      setProducts((items) => items.filter((item) => item.id !== product.id));
      setNotice(`${product.product_name} was deleted.`);
    } catch (err) { setError(err.message); }
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Boxes size={22} strokeWidth={2.4} /></div>
          <div><strong>stockwise</strong><span>INVENTORY CLOUD</span></div>
          <button className="icon-btn mobile-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="nav-list">
          <a className="nav-link active" href="#overview"><LayoutDashboard size={18}/><span>Overview</span><span className="nav-dot"/></a>
          <a className="nav-link" href="#inventory"><Package size={18}/><span>Inventory</span><span className="nav-count">{products.length}</span></a>
        </nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon"><Sparkles size={17}/></div>
            <strong>Keep stock in check</strong>
            <p>Stay on top of every item and make smarter stock decisions.</p>
            <a href="#inventory">Explore inventory <ArrowUpRight size={14}/></a>
          </div>
          <div className="profile">
            <div className="avatar">SM</div>
            <div className="profile-text"><strong>Store Manager</strong><span>Administrator</span></div>
            <MoreHorizontal size={19} className="profile-more"/>
          </div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={20}/></button>
          <div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>Overview</strong></div>
          <div className="topbar-right">
            <div className="live-status"><span/> System operational</div>
            <div className="top-avatar">SM</div>
          </div>
        </header>

        <div className="content-wrap" id="overview">
          <section className="welcome-row">
            <div>
              <div className="eyebrow"><span className="eyebrow-line"/> INVENTORY OVERVIEW</div>
              <h1>Your stock, <span>in control.</span></h1>
              <p className="welcome-sub">A clear view of what you have, what it's worth, and what needs attention.</p>
            </div>
            <button className="primary-btn" onClick={openCreate}><Plus size={18}/> Add a product</button>
          </section>

          {error && <div className="alert alert-error"><AlertTriangle size={17}/><span>{error}</span><button onClick={() => setError('')}><X size={16}/></button></div>}
          {notice && <div className="alert alert-success"><Check size={17}/><span>{notice}</span><button onClick={() => setNotice('')}><X size={16}/></button></div>}

          <section className="stats-grid">
            <StatCard title="Total products" value={products.length.toLocaleString()} note="Unique items in catalogue" icon={<Package size={19}/>} tone="violet" trend="Live count"/>
            <StatCard title="Units in stock" value={totalUnits.toLocaleString()} note="Across all products" icon={<Boxes size={19}/>} tone="blue" trend="Total quantity"/>
            <StatCard title="Inventory value" value={money(inventoryValue)} note="Quantity × unit price" icon={<CircleDollarSign size={19}/>} tone="green" trend="Current value"/>
            <StatCard title="Low stock alerts" value={lowStock.toLocaleString()} note="Products with 5 units or less" icon={<AlertTriangle size={19}/>} tone="amber" trend={lowStock ? 'Needs attention' : 'All looking good'} warning={lowStock > 0}/>
          </section>

          <section className="insight-strip">
            <div className="insight-icon"><Activity size={18}/></div>
            <div className="insight-copy"><strong>Inventory snapshot</strong><span>{products.length ? `${products.length} products across ${new Set(products.map(p => p.category)).size} categories. Average unit price: ${money(avgPrice)}.` : 'Add your first product to start building your inventory snapshot.'}</span></div>
            <div className="insight-tag"><ShieldCheck size={14}/> LIVE DATA</div>
          </section>

          <section className="inventory-section" id="inventory">
            <div className="section-heading">
              <div><div className="eyebrow">YOUR CATALOGUE</div><h2>Product inventory <span className="count-pill">{products.length}</span></h2><p>Manage, track and update the items in your store.</p></div>
              <button className="secondary-btn refresh-btn" onClick={loadProducts} disabled={loading}><RefreshCw size={15} className={loading ? 'spin' : ''}/> Refresh</button>
            </div>
            <div className="table-toolbar">
              <div className="search-box"><Search size={17}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products, categories or ID..." /></div>
              <div className="filter-wrap"><ClipboardList size={16}/><select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>{categories.map(c => <option key={c}>{c}</option>)}</select><ChevronDown size={14}/></div>
            </div>

            <div className="table-card">
              <div className="table-scroll">
                <table>
                  <thead><tr><th>PRODUCT</th><th>CATEGORY</th><th>QUANTITY</th><th>UNIT PRICE</th><th>STOCK STATUS</th><th className="actions-head">ACTIONS</th></tr></thead>
                  <tbody>
                    {loading ? <tr><td colSpan="6"><div className="table-state"><RefreshCw className="spin" size={20}/> Loading your inventory...</div></td></tr> :
                    filtered.length === 0 ? <tr><td colSpan="6"><div className="empty-state"><div className="empty-icon"><Package size={24}/></div><strong>{products.length ? 'No matching products' : 'Your inventory is waiting'}</strong><span>{products.length ? 'Try a different search or category.' : 'Add a product to see it appear here.'}</span>{!products.length && <button className="primary-btn small-btn" onClick={openCreate}><Plus size={15}/> Add first product</button>}</div></td></tr> :
                    filtered.map((p) => <ProductRow key={p.id} product={p} onEdit={openEdit} onDelete={deleteProduct}/>)}
                  </tbody>
                </table>
              </div>
              <div className="table-footer"><span>Showing <strong>{filtered.length}</strong> of <strong>{products.length}</strong> products</span><span className="footer-secure"><ShieldCheck size={14}/> Synced with database</span></div>
            </div>
          </section>
          <footer className="footer"><span>© 2025 Stockwise Inventory</span><span>Thoughtful stock management, made simple.</span></footer>
        </div>
      </main>

      {modalOpen && <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) closeModal(); }}>
        <div className="modal">
          <div className="modal-head"><div><div className="eyebrow">{editing ? 'UPDATE RECORD' : 'NEW INVENTORY ITEM'}</div><h2>{editing ? 'Edit product' : 'Add a product'}</h2><p>Fill in the details below to {editing ? 'update this item' : 'add it to your inventory'}.</p></div><button className="icon-btn" onClick={closeModal} aria-label="Close"><X size={19}/></button></div>
          <form onSubmit={submitProduct}>
            <div className="form-grid">
              <label className="field full-field">Product name<input name="product_name" value={form.product_name} onChange={updateField} placeholder="e.g. Premium white rice" maxLength="100" required autoFocus/></label>
              <label className="field full-field">Category<input name="category" value={form.category} onChange={updateField} placeholder="e.g. Food, Hygiene, Drinks" maxLength="80" required/></label>
              <label className="field">Quantity<input name="quantity" type="number" min="1" step="1" value={form.quantity} onChange={updateField} placeholder="0" required/></label>
              <label className="field">Unit price <span className="field-hint">RWF</span><input name="unit_price" type="number" min="0" max="99999999.99" step="0.01" value={form.unit_price} onChange={updateField} placeholder="0" required/></label>
            </div>
            <div className="modal-note"><ShieldCheck size={16}/> Product ID is generated automatically by MySQL.</div>
            <div className="modal-actions"><button type="button" className="secondary-btn" onClick={closeModal} disabled={saving}>Cancel</button><button className="primary-btn" type="submit" disabled={saving}>{saving ? 'Saving...' : <>{editing ? <Check size={17}/> : <Plus size={17}/>} {editing ? 'Save changes' : 'Add product'}</>}</button></div>
          </form>
        </div>
      </div>}
    </div>
  );
}

function StatCard({ title, value, note, icon, tone, trend, warning }) {
  return <article className="stat-card"><div className="stat-top"><div className={`stat-icon ${tone}`}>{icon}</div><span className={`stat-trend ${warning ? 'trend-warning' : ''}`}>{warning ? <ArrowDownRight size={13}/> : <ArrowUpRight size={13}/>} {trend}</span></div><div className="stat-title">{title}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></article>;
}

function ProductRow({ product, onEdit, onDelete }) {
  const qty = Number(product.quantity);
  const status = qty <= 5 ? 'Low stock' : qty <= 15 ? 'Moderate' : 'In stock';
  const initials = product.product_name.split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase();
  return <tr>
    <td><div className="product-cell"><div className="product-avatar">{initials}</div><div><strong>{product.product_name}</strong><span>SKU-{String(product.id).padStart(4, '0')}</span></div></div></td>
    <td><span className="category-chip">{product.category}</span></td>
    <td><strong className="quantity-value">{qty}</strong><span className="units-label"> units</span></td>
    <td><strong className="price-value">{money(product.unit_price)}</strong></td>
    <td><span className={`status-pill ${status === 'Low stock' ? 'status-low' : status === 'Moderate' ? 'status-medium' : 'status-good'}`}><span/> {status}</span></td>
    <td><div className="row-actions"><button onClick={() => onEdit(product)} className="action-btn edit-action" title="Edit product"><Edit3 size={15}/><span>Edit</span></button><button onClick={() => onDelete(product)} className="action-btn delete-action" title="Delete product"><Trash2 size={15}/></button></div></td>
  </tr>;
}

export default App;
