const express = require('express');
const db = require('../config/database');
const router = express.Router();

function validateProduct(body) {
  const name = String(body.product_name ?? '').trim();
  const category = String(body.category ?? '').trim();
  const quantity = Number(body.quantity);
  const unitPrice = Number(body.unit_price);

  if (!name || !category) return { error: 'Product name and category are required.' };
  if (name.length > 100 || category.length > 80) return { error: 'Name must be at most 100 characters and category at most 80.' };
  if (!Number.isInteger(quantity) || quantity <= 0) return { error: 'Quantity must be a positive whole number.' };
  if (!Number.isFinite(unitPrice) || unitPrice < 0 || unitPrice > 99999999.99) return { error: 'Unit price must be a valid non-negative amount.' };
  return { values: [name, category, quantity, unitPrice] };
}

// GET /api/products — list all products
router.get('/', async (_req, res, next) => {
  try {
    const [rows] = await db.query(
      'SELECT id, product_name, category, quantity, unit_price, created_at, updated_at FROM products ORDER BY created_at DESC, id DESC'
    );
    res.json({ success: true, count: rows.length, data: rows });
  } catch (error) { next(error); }
});

// POST /api/products — register a product
router.post('/', async (req, res, next) => {
  const checked = validateProduct(req.body);
  if (checked.error) return res.status(400).json({ success: false, message: checked.error });
  try {
    const [result] = await db.execute(
      'INSERT INTO products (product_name, category, quantity, unit_price) VALUES (?, ?, ?, ?)',
      checked.values
    );
    const [rows] = await db.execute('SELECT * FROM products WHERE id = ?', [result.insertId]);
    res.status(201).json({ success: true, message: 'Product added successfully.', data: rows[0] });
  } catch (error) { next(error); }
});

// PUT /api/products/:id — update a product
router.put('/:id', async (req, res, next) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ success: false, message: 'Invalid product ID.' });
  const checked = validateProduct(req.body);
  if (checked.error) return res.status(400).json({ success: false, message: checked.error });
  try {
    const [result] = await db.execute(
      'UPDATE products SET product_name = ?, category = ?, quantity = ?, unit_price = ? WHERE id = ?',
      [...checked.values, id]
    );
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Product not found.' });
    const [rows] = await db.execute('SELECT * FROM products WHERE id = ?', [id]);
    res.json({ success: true, message: 'Product updated successfully.', data: rows[0] });
  } catch (error) { next(error); }
});

// DELETE /api/products/:id
router.delete('/:id', async (req, res, next) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ success: false, message: 'Invalid product ID.' });
  try {
    const [result] = await db.execute('DELETE FROM products WHERE id = ?', [id]);
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Product not found.' });
    res.json({ success: true, message: 'Product deleted successfully.' });
  } catch (error) { next(error); }
});

module.exports = router;
