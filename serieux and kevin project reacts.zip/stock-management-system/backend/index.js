require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./config/database');
const productRoutes = require('./routes/products');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', async (_req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ success: true, message: 'API and MySQL are connected.' });
  } catch (_error) {
    res.status(503).json({ success: false, message: 'API is running, but the database is unavailable.' });
  }
});

app.use('/api/products', productRoutes);
app.use((_req, res) => res.status(404).json({ success: false, message: 'Endpoint not found.' }));
app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({
    success: false,
    message: 'A server error occurred. Check the backend terminal for details.'
  });
});

const port = Number(process.env.PORT || 5000);
app.listen(port, () => console.log(`Stock Management API running at http://localhost:${port}`));
